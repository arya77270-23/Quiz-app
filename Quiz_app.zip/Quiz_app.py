import tkinter as tk
from tkinter import messagebox
import time
questions = [
    "Which unit is responsible for converting the data received from the user into a computer understandable format?",
    "Which language is used for web apps?",
    "Who developed Python?",
    "Which one is a Python framework?",
    "What year was Python created?",
    "The only language which the computer understands is?",
    "Which of the following is not a programming language?",
    "What does HTML stand for?",
    "Which company developed the Java programming language?",
    "What is the extension of Python files?"
]
options = [
    ["Input Unit", "Output Unit", "Storage Unit", "CPU"],
    ["Python", "Java", "HTML", "C++"],
    ["Guido van Rossum", "Elon Musk", "Dennis Ritchie", "Mark Zuckerberg"],
    ["Django", "React", "Laravel", "Flutter"],
    ["1989", "1991", "2000", "1995"],
    ["Binary", "English", "Java", "C++"],
    ["Python", "Java", "HTML", "C++"],
    ["HyperText Markup Language", "Home Tool Markup Language", "Hyperlinks and Text Markup Language", "None of these"],
    ["Sun Microsystems", "Microsoft", "Google", "Apple"],
    [".py", ".java", ".cpp", ".txt"]
]
answers = [0, 2, 0, 0, 1, 0, 2, 0, 0, 0]
class QuizApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Quiz Application")
        self.master.geometry("600x450")
        self.master.config(bg="#88B0A2")
        self.time_left = 600
        self.timer_running = False
        self.create_welcome_screen()
    def create_welcome_screen(self):
        """Welcome page with Start and Quit buttons"""
        for widget in self.master.winfo_children():
            widget.destroy()
        title_label = tk.Label(self.master, text="Welcome to Python Quiz!",
                            font=("Times New Roman", 22, "bold"), bg="#88B0A2", fg="#333")
        title_label.pack(pady=40)
        instruction_label = tk.Label(self.master,
                                    text="Test your Python knowledge.",
                                    font=("Times New Roman", 14,"bold"), bg="#88B0A2", fg="#333")
        instruction_label.pack(pady=10)
        start_button = tk.Button(self.master, text="Start Quiz", command=self.start_quiz,
                                font=("Times New Roman", 14, "bold"), bg="#35443F", fg="white", width=15)
        start_button.pack(pady=20)
        quit_button = tk.Button(self.master, text="Quit", command=self.quit_app,
                                font=("Times New Roman", 14, "bold"), bg="#7A3B1D", fg="white", width=15)
        quit_button.pack(pady=10)
    def start_quiz(self):
        for widget in self.master.winfo_children():
            widget.destroy()
        self.score = 0
        self.current_question = 0
        self.time_left = 600 
        self.timer_running = True
        self.title_label = tk.Label(self.master, text="Python Quiz", font=("Times New Roman", 20, "bold"), bg="#88B0A2", fg="#333")
        self.title_label.pack(pady=5)
        self.timer_label = tk.Label(self.master, text="", font=("Times New Roman", 14, "bold"), bg="#88B0A2", fg="#35443F")
        self.timer_label.pack()
        self.update_timer()
        self.question_label = tk.Label(self.master, text="", font=("Times New Roman", 14, "bold"), bg="#88B0A2",
                                    wraplength=550, justify="left", fg="#333")
        self.question_label.pack(pady=20)
        self.var = tk.IntVar()
        self.option_buttons = []
        for i in range(4):
            rb = tk.Radiobutton(self.master, text="", variable=self.var, value=i,
                                font=("Times New Roman", 12, "bold"), bg="#88B0A2", anchor="w", fg="#333")
            rb.pack(fill="x", padx=50, pady=5)
            self.option_buttons.append(rb)
        self.next_button = tk.Button(self.master, text="Next ➡", command=self.next_question,
                                    font=("Times New Roman", 12, "bold"), bg="#35443F", fg="white", width=10)
        self.next_button.pack(pady=20)
        self.display_question()
    def update_timer(self):
        if self.timer_running:
            minutes, seconds = divmod(self.time_left, 60)
            self.timer_label.config(text=f"Time Left: {minutes:02}:{seconds:02}")
            if self.time_left > 0:
                self.time_left -= 1
                self.master.after(1000, self.update_timer)
            else:
                self.timer_running = False
                messagebox.showinfo("Times Up!")
                self.show_result()
    def display_question(self):
        if self.current_question < len(questions):
            self.var.set(-1)
            self.question_label.config(text=f"Q{self.current_question + 1}. {questions[self.current_question]}")
            for i, option in enumerate(options[self.current_question]):
                self.option_buttons[i].config(text=option)
        else:
            self.show_result()
    def next_question(self):
        selected = self.var.get()
        if selected == -1:
            messagebox.showwarning("Select an Option", "Please select an answer before proceeding.")
            return
        if selected == answers[self.current_question]:
            self.score += 1
        self.current_question += 1
        if self.current_question == len(questions):
            self.show_result()
        else:
            self.display_question()
    def show_result(self):
        self.timer_running = False
        for widget in self.master.winfo_children():
            widget.destroy()
        score_text = f"Your Score: {self.score} / {len(questions)}"
        percentage = int((self.score / len(questions)) * 100)
        result_label = tk.Label(self.master, text="Quiz Completed!", font=("Times New Roman", 20, "bold"), bg="#88B0A2", fg="#333")
        result_label.pack(pady=20)
        score_label = tk.Label(self.master, text=score_text, font=("Times New Roman", 16, "bold"), bg="#88B0A2", fg="#333")
        score_label.pack(pady=10)
        percentage_label = tk.Label(self.master, text=f"Percentage: {percentage}%", font=("Times New Roman", 16, "bold"), bg="#88B0A2", fg="#333")
        percentage_label.pack(pady=10)
        if percentage >= 80:
            remark = "Excellent Work!"
        elif percentage >= 50:
            remark = "Good Job!"
        else:
            remark = "Keep Practicing!"
        remark_label = tk.Label(self.master, text=remark, font=("Times New Roman", 14, "bold"), bg="#88B0A2", fg="#333")
        remark_label.pack(pady=10)
        restart_button = tk.Button(self.master, text="Restart", command=self.create_welcome_screen,
                                font=("Times New Roman", 12, "bold"), bg="#35443F", fg="white", width=10)
        restart_button.pack(pady=10)
        quit_button = tk.Button(self.master, text="Quit", command=self.quit_app,
                                font=("Times New Roman", 12, "bold"), bg="#7A3B1D", fg="white", width=10)
        quit_button.pack(pady=10)
    def quit_app(self):
        confirm = messagebox.askyesno("Exit", "Are you sure you want to quit?")
        if confirm:
            self.master.destroy()
if __name__ == "__main__":
    root = tk.Tk()
    app = QuizApp(root)
    root.mainloop()
